## improved legendware
> internal rage cheat for cs:go

## "soma projects" community servers

- if you want other good sources [click here!](https://discord.gg/invite/WPag8RJ)

## how to's

- build the project with v141 build tools (v142 don't work)
